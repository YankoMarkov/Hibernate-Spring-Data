create procedure usp_get_holders_with_balance_higher_than(IN input_number decimal(12, 4))
  BEGIN
	SELECT 
    ah.first_name, ah.last_name
	FROM
    `account_holders` AS ah
        INNER JOIN
    (SELECT 
        a.id, a.account_holder_id, SUM(a.balance) AS 'total'
    FROM
        `accounts` AS a
    GROUP BY a.account_holder_id) AS `total_sum` ON ah.id = total_sum.account_holder_id
	WHERE
    total_sum.total > input_number
ORDER BY total_sum.id , ah.first_name , ah.last_name;
END;

