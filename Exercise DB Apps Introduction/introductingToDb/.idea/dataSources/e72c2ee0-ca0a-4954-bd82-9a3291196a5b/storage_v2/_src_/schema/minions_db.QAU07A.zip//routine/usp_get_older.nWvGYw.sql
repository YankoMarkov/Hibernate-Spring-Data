create procedure usp_get_older(IN minion_id int)
  BEGIN
    UPDATE minions SET age = age + 1 WHERE id = minion_id;
  END;

