create trigger tr_insert_logs
  after INSERT
  on logs
  for each row
BEGIN
	DECLARE new_subject VARCHAR(50);
    DECLARE new_body VARCHAR(90);
    SET new_subject := concat('Balance change for account: ',NEW.account_id);
    SET new_body := concat('On ', NOW(), ' your balance was changed from ', NEW.old_sum, ' to ', NEW.new_sum, '.');
	INSERT INTO `notification_emails` (recipient, subject, body)
    VALUES (NEW.account_id, new_subject, new_body);
END;

