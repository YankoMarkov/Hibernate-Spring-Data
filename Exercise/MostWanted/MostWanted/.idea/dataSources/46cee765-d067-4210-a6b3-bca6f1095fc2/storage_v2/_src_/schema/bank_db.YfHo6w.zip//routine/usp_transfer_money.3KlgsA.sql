create procedure usp_transfer_money(IN from_account_id int, IN to_account_id int, IN amount decimal(20, 4))
BEGIN
	DECLARE new_amount DECIMAL(20,4);
    IF (amount >= 0) THEN
		START TRANSACTION;
        SET new_amount := (SELECT a.balance FROM `accounts` AS a
				WHERE a.id = from_account_id);
		IF ((SELECT COUNT(a.id) FROM `accounts` AS a
			WHERE a.id LIKE from_account_id) <> 1) THEN
        ROLLBACK;
        ELSEIF ((SELECT COUNT(a.id) FROM `accounts` AS a
			WHERE a.id LIKE to_account_id) <> 1) THEN
		ROLLBACK;
        ELSEIF (new_amount < amount) THEN
		ROLLBACK;
        ELSE UPDATE `accounts` AS a
			SET a.balance = a.balance + amount
            WHERE a.id = to_account_id;
            UPDATE `accounts` AS a
            SET a.balance = a.balance - amount
            WHERE a.id = from_account_id;
		END IF;
	END IF;
END;

