package alararestaurant.domain.enums;

public enum OrderType {
	ForHere, ToGo
}
