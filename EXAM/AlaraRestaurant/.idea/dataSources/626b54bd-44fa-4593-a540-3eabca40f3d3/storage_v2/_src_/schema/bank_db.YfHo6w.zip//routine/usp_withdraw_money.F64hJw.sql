create procedure usp_withdraw_money(IN account_id int, IN money_amount decimal(20, 4))
BEGIN
	IF (money_amount >= 0) THEN
		START TRANSACTION;
        IF ((SELECT COUNT(a.id) FROM `accounts` AS a
			WHERE a.id LIKE account_id) <> 1) THEN
		ROLLBACK;
        ELSEIF ((SELECT a.balance FROM `accounts` AS a 
            WHERE a.id = account_id) < money_amount) THEN
		ROLLBACK;
		ELSE UPDATE `accounts` AS a
			SET a.balance = a.balance - money_amount
            WHERE a.id = account_id;
		END IF;
	END IF;
END;

