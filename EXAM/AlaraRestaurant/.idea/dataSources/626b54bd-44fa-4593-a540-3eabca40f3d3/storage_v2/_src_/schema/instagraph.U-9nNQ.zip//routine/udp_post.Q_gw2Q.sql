create procedure udp_post(IN username varchar(30), IN password varchar(30), IN caption varchar(255),
                          IN path varchar(255))
BEGIN
	DECLARE user_id INT;
    DECLARE picture_id INT;
    
    IF ((SELECT COUNT(*) FROM `users` AS u
    WHERE u.username = username) <> 1) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No such user!';
    
    ELSEIF ((SELECT COUNT(*) FROM `users` AS u
    WHERE u.password = password) <> 1) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Password is incorrect!';
    
    ELSEIF ((SELECT COUNT(*) FROM `pictures` AS p
    WHERE p.path = path) <> 1) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The picture does not exist!';
    
    END IF;
    
	SELECT u.id FROM `users` AS u
	WHERE u.username = username;
	
	SELECT p.id FROM `pictures` AS p
	WHERE p.path = path;
    
    INSERT INTO `posts` (caption, user_id, picture_id)
    VALUES (caption, user_id, picture_id);
END;

