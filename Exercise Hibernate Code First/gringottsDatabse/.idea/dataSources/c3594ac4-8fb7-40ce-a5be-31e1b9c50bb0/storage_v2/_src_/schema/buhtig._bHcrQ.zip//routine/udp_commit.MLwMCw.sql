create procedure udp_commit(IN username varchar(30), IN password varchar(30), IN message varchar(255), IN issue_id int)
  BEGIN
	DECLARE contributor_id INT;
    DECLARE repository_id INT;
    
    IF ((SELECT COUNT(*) FROM `users` AS u
    WHERE u.username = username) <> 1) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No such user!';
    
    ELSEIF ((SELECT COUNT(*) FROM `users` AS u
    WHERE u.password = password) <> 1) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Password is incorrect!';
    
    ELSEIF ((SELECT COUNT(*) FROM `issues` AS i
    WHERE i.id = issue_id) <> 1) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The issue does not exist!';
    
    END IF;
    
	SET contributor_id := (SELECT u.id FROM `users` AS u
    WHERE u.username = username);
    
    SET repository_id := (SELECT i.repository_id FROM `issues` AS i
    WHERE i.id = issue_id);
    
    INSERT INTO `commits` (message, issue_id, repository_id, contributor_id)
    VALUES (message, issue_id, repository_id, contributor_id);
    
END;

