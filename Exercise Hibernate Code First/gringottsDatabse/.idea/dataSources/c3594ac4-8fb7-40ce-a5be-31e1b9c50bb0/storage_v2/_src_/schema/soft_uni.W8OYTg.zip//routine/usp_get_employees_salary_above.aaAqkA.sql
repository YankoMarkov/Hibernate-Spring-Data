create procedure usp_get_employees_salary_above(IN salary_number decimal(19, 4))
  BEGIN
SELECT e.first_name, e.last_name FROM `employees` AS e
WHERE e.salary >= salary_number
ORDER BY e.first_name, e.last_name, e.employee_id;
END;

