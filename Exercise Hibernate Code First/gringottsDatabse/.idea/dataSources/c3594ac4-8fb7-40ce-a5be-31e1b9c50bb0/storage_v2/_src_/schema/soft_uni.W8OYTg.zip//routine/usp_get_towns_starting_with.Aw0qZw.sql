create procedure usp_get_towns_starting_with(IN town_starting_with varchar(50))
  BEGIN
SELECT t.name AS 'town_name' FROM `towns` AS t
WHERE lower(t.name) LIKE lower(CONCAT(town_starting_with, '%'))
ORDER BY t.name;
END;

