create function ufn_calculate_future_value(initial_sum int, yearly_interest_rate decimal(19, 4), number_of_years int)
  returns decimal(19, 4)
  BEGIN
	DECLARE result DECIMAL(19,4);
    SET result := initial_sum * (pow((1 + yearly_interest_rate), number_of_years));
    RETURN result;
END;

