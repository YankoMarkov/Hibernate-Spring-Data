create procedure usp_get_employees_by_salary_level(IN salary_level varchar(10))
  BEGIN
	SELECT e.first_name, e.last_name FROM `employees` AS e
	WHERE lower(ufn_get_salary_level (e.salary)) = lower(salary_level)
    ORDER BY e.first_name DESC, e.last_name DESC;
END;

