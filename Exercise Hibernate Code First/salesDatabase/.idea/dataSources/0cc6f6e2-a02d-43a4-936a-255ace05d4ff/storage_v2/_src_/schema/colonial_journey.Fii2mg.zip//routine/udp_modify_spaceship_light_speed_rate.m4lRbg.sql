create procedure udp_modify_spaceship_light_speed_rate(IN spaceship_name varchar(50), IN light_speed_rate_increse int)
  BEGIN
    IF ((SELECT COUNT(*) FROM `spaceships` AS s WHERE s.name = spaceship_name) <> 1) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Spaceship you are trying to modify does not exists.';
    END IF;
    
    UPDATE `spaceships` AS s
    SET s.light_speed_rate = s.light_speed_rate + light_speed_rate_increse
    WHERE s.name = spaceship_name;
END;

