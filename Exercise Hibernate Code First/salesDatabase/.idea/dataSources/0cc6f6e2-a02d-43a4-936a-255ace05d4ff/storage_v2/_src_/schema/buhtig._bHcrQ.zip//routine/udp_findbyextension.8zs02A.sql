create procedure udp_findbyextension(IN extension varchar(100))
  BEGIN
	SELECT f.id, f.name, concat(f.size,'KB') FROM `files` AS f
    WHERE f.name LIKE concat('%', extension);
END;

