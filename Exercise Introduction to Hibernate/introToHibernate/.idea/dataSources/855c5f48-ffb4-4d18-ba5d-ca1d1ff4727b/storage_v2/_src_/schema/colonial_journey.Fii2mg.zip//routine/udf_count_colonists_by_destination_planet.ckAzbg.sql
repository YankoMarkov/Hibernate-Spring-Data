create function udf_count_colonists_by_destination_planet(planet_name varchar(30))
  returns int
  BEGIN
	DECLARE colonist_count INT;
    SET colonist_count := (SELECT COUNT(*) AS `count` FROM `planets` AS p
    INNER JOIN `spaceports` AS s ON p.id = planet_id
    INNER JOIN `journeys` AS j ON s.id = j.destination_spaceport_id
    INNER JOIN `travel_cards` AS tc ON j.id = tc.journey_id
    INNER JOIN `colonists` AS c ON tc.colonist_id = c.id
    WHERE p.name = planet_name);
    RETURN colonist_count;
END;

